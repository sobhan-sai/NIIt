export MYSQL_DATABASE=food
export MYSQL_USER=root
export MYSQL_PASSWORD=root
export MYSQL_CI_URL=jdbc:mysql://localhost:3306/food