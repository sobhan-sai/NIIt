package com.stackroute.userservice.exception;

public class UserAlreadyExistsException extends Exception {
	
	public UserAlreadyExistsException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}


}
