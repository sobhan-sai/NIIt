cd userservice
source ./env-variable.sh
cd ..
cd favouriteservice
source ./env-variable.sh
cd ..