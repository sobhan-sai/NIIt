export class Food{
    id:string;
    ndbno:string;
    name:string;
    
}