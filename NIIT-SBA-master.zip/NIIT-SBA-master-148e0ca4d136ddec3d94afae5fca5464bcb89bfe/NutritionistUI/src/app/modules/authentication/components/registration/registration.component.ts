import { Component, OnInit } from '@angular/core';
import { User } from '../../user';
import { AuthenticationService } from '../../authentication.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'user-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  newUser: User = new User();
  constructor(private authService: AuthenticationService,
    private router: Router) { }

  ngOnInit() {
  }

  registerUser() {
    console.log("Register User data:", this.newUser);
    this.authService.registerUser(this.newUser).subscribe(data => {
      console.log("User registered", data);
      this.router.navigate(['/login']);
    },(error:HttpErrorResponse) => {
      if((error.status==409)&&(error.statusText=="OK"))
      {
          alert("UserId already exists");
        
          console.log("User already exists");
      }
      else{
      console.log("Error", error);
      }
  }

    );
  }

}
